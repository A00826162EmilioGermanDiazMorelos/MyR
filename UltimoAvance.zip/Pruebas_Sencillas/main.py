import ply.lex as lex
import ply.yacc as yacc

reserved = {
    'Program': 'PROGRAM',
    'main': 'MAIN',
    'int': 'INT',
    'flot': 'FLOT',
    'char': 'CHAR',
    'void': 'VOID',
    'vars': 'VARS',
    'function': 'FUNCTION',
    'return': 'RETURN',
    'read': 'READ',
    'write': 'WRITE',
    'If': 'IF',
    'then': 'THEN',
    'else': 'ELSE',
    'while': 'WHILE',
    'for': 'FOR',
    'to': 'TO',
    'do': 'DO'
}

tokens = ['PLUS', 'MINUS', 'MULT', 'DIV', 'EQUALS', 'AND', 'OR', 'LESS_THAN', 'MORE_THAN',
          'EQUAL_TO', 'NUMBER', 'CONST_FLOAT', 'NAME', 'LEFTPAREN', 'RIGHTPAREN', 'LEFTCURLY', 'RIGHTCURLY',
          'LEFTSQUARE', 'RIGHTSQUARE', 'PUNT_COMA', 'COMA', 'COMILLAS'] + list(reserved.values())

# Ignorar espacios en blanco y saltos de línea
t_ignore = ' \t'

# Expresiones regulares para operaciones aritméticas
t_PLUS = r'\+'
t_MINUS = r'-'
t_MULT = r'\*'
t_DIV = r'/'
t_EQUALS = r'='

# Expresiones regulares para operaciones lógicas
t_AND = r'&'
t_OR = r'\|'
t_LESS_THAN = r'<'
t_MORE_THAN = r'>'
t_EQUAL_TO = r'=='

# Expresiones regulares para abrir y cerrar paréntesis, corchetes y llaves, y signos de puntuación
t_LEFTPAREN = r'\('
t_RIGHTPAREN = r'\)'
t_LEFTCURLY = r'\{'
t_RIGHTCURLY = r'\}'
t_LEFTSQUARE = r'\['
t_RIGHTSQUARE = r'\]'
t_PUNT_COMA = r';'
t_COMA = r','
t_COMILLAS = r'"'

# Expresión regular para reconocer números enteros
def t_NUMBER(t):
    r'\d+'
    t.value = int(t.value)
    return t

def t_CONST_FLOAT(t):
    r'\d\.\d+'
    t.value = float(t.value)
    return t

def t_NAME(t):
    r'[a-zA-Z_][a-zA-Z_0-9]*'
    t.type = reserved.get(t.value, 'NAME')  # Checa palabras reservadas
    return t

# Manejo de errores
def t_error(t):
    print(f"Caracter ilegal: {t.value[0]}")
    t.lexer.skip(1)

# Construir el lexer
lexer = lex.lex()

# PARSER
class ProcedureEntry:
    def __init__(self, name, return_type, parameters, start_address):
        self.name = name
        self.return_type = return_type
        self.parameters = parameters  # Esto podría ser una lista de (tipo, nombre)
        self.start_address = start_address
        self.local_variables = {}  # Esto es un diccionario para las variables locales

    def add_variable(self, var_name, var_type):
        self.local_variables[var_name] = var_type

    def __repr__(self):
        return (f"Procedure {self.name}: Return Type: {self.return_type}, "
                f"Parameters: {self.parameters}, Start Address: {self.start_address}, "
                f"Local Variables: {self.local_variables}")


class ProcedureDirectory:
    def __init__(self):
        self.procedures = {}

    def add_procedure(self, name, return_type, parameters, start_address):
        if name in self.procedures:
            raise ValueError(f"Procedure '{name}' already defined")
        self.procedures[name] = ProcedureEntry(name, return_type, parameters, start_address)

    def get_procedure(self, name):
        return self.procedures.get(name)

    def __repr__(self):
        return "\n".join(str(proc) for proc in self.procedures.values())

procedure_directory = ProcedureDirectory()

#Tabla de simbolos

class SymbolTableEntry:
    def __init__(self, name, symbol_type, scope, address=None):
        self.name = name
        self.symbol_type = symbol_type
        self.scope = scope
        self.address = address

    def __repr__(self):
        return f"Symbol(name={self.name}, type={self.symbol_type}, scope={self.scope}, address={self.address})"

class SymbolTable:
    def __init__(self):
        self.table = {}

    def add(self, name, symbol_type, scope, address=None):
        if name in self.table:
            raise ValueError(f"Symbol {name} already defined in current scope")
        entry = SymbolTableEntry(name, symbol_type, scope, address)
        self.table[name] = entry

    def lookup(self, name):
        return self.table.get(name)

    def __repr__(self):
        return str(self.table)

class ScopeManager:
    def __init__(self):
        self.global_scope = SymbolTable()
        self.scopes = [self.global_scope]

    def enter_scope(self):
        self.scopes.append(SymbolTable())

    def exit_scope(self):
        self.scopes.pop()

    def current_scope(self):
        return self.scopes[-1]

    def add_symbol(self, name, symbol_type, scope, address=None):
        self.current_scope().add(name, symbol_type, scope, address)

    def lookup(self, name):
        for scope in reversed(self.scopes):
            symbol = scope.lookup(name)
            if symbol:
                return symbol
        return None

#Cuádruplos

class Quadruple:
    def __init__(self, operator, operand1, operand2, result):
        self.operator = operator
        self.operand1 = operand1
        self.operand2 = operand2
        self.result = result

quadruples = []

def add_quadruple(operator, operand1, operand2, result):
    quadruple = Quadruple(operator, operand1, operand2, result)
    quadruples.append(quadruple)
    return quadruple

def get_quadruple(index):
    return quadruples[index]

# Funciones para manejar cuádruplos

def print_quadruples():
    for i, quad in enumerate(quadruples):
        print(f"{i}: {quad}")

# Generación de Variables Temporales

temp_counter = 0

def generate_temporary():
    global temp_counter
    temp_name = f"temp{temp_counter}"
    temp_counter += 1
    return temp_name

# Pilas de Operadores, Operandos y Saltos

operators_stack = []
operands_stack = []
jumps_stack = []
symbol_table = []


#Cubo Semántico
#posibles tipos de datos
types = ['int', 'float', 'char', 'bool']
#operadores binarios
operators = ['+', '-', '*', '/', '==', '<', '>', '&&', '||']

semantic_cube = {}

#Operaciones +, -, /, *, mismo tipo
semantic_cube[('int', 'int', '+')] = 'int'
semantic_cube[('int', 'int', '-')] = 'int'
semantic_cube[('int', 'int', '*')] = 'int'
semantic_cube[('int', 'int', '/')] = 'int'

semantic_cube[('float', 'float', '+')] = 'float'
semantic_cube[('float', 'float', '-')] = 'float'
semantic_cube[('float', 'float', '*')] = 'float'
semantic_cube[('float', 'float', '/')] = 'float'

semantic_cube[('char', 'char', '+')] = 'Error'
semantic_cube[('char', 'char', '-')] = 'Error'
semantic_cube[('char', 'char', '*')] = 'Error'
semantic_cube[('char', 'char', '/')] = 'Error'

semantic_cube[('bool', 'bool', '+')] = 'Error'
semantic_cube[('bool', 'bool', '-')] = 'Error'
semantic_cube[('bool', 'bool', '*')] = 'Error'
semantic_cube[('bool', 'bool', '/')] = 'Error'

#Operaciones +, -, /, *, int y diferente tipo
semantic_cube[('int', 'float', '+')] = 'float'
semantic_cube[('int', 'char', '+')] = 'Error'
semantic_cube[('int', 'bool', '+')] = 'Error'

semantic_cube[('int', 'float', '-')] = 'float'
semantic_cube[('int', 'char', '-')] = 'Error'
semantic_cube[('int', 'bool', '-')] = 'Error'

semantic_cube[('int', 'float', '*')] = 'float'
semantic_cube[('int', 'char', '*')] = 'Error'
semantic_cube[('int', 'bool', '*')] = 'Error'

semantic_cube[('int', 'float', '/')] = 'float'
semantic_cube[('int', 'char', '/')] = 'Error'
semantic_cube[('int', 'bool', '/')] = 'Error'

#Operaciones +, -, /, *, float y diferente tipo
semantic_cube[('float', 'int', '+')] = 'float'
semantic_cube[('float', 'char', '+')] = 'Error'
semantic_cube[('float', 'bool', '+')] = 'Error'

semantic_cube[('float', 'int', '-')] = 'float'
semantic_cube[('float', 'char', '-')] = 'Error'
semantic_cube[('float', 'bool', '-')] = 'Error'

semantic_cube[('float', 'int', '*')] = 'float'
semantic_cube[('float', 'char', '*')] = 'Error'
semantic_cube[('float', 'bool', '*')] = 'Error'

semantic_cube[('float', 'int', '/')] = 'float'
semantic_cube[('float', 'char', '/')] = 'Error'
semantic_cube[('float', 'bool', '/')] = 'Error'

#Operaciones +, -, /, *, char y diferente tipo
semantic_cube[('char', 'int', '+')] = 'Error'
semantic_cube[('char', 'float', '+')] = 'Error'
semantic_cube[('char', 'bool', '+')] = 'Error'

semantic_cube[('char', 'int', '-')] = 'Error'
semantic_cube[('char', 'float', '-')] = 'Error'
semantic_cube[('char', 'bool', '-')] = 'Error'

semantic_cube[('char', 'int', '*')] = 'Error'
semantic_cube[('char', 'float', '*')] = 'Error'
semantic_cube[('char', 'bool', '*')] = 'Error'

semantic_cube[('char', 'int', '/')] = 'Error'
semantic_cube[('char', 'float', '/')] = 'Error'
semantic_cube[('char', 'bool', '/')] = 'Error'

#Operaciones +, -, /, *, bool y diferente tipo
semantic_cube[('bool', 'int', '+')] = 'Error'
semantic_cube[('bool', 'float', '+')] = 'Error'
semantic_cube[('bool', 'char', '+')] = 'Error'

semantic_cube[('bool', 'int', '-')] = 'Error'
semantic_cube[('bool', 'float', '-')] = 'Error'
semantic_cube[('bool', 'char', '-')] = 'Error'

semantic_cube[('bool', 'int', '*')] = 'Error'
semantic_cube[('bool', 'float', '*')] = 'Error'
semantic_cube[('bool', 'char', '*')] = 'Error'

semantic_cube[('bool', 'int', '/')] = 'Error'
semantic_cube[('bool', 'float', '/')] = 'Error'
semantic_cube[('bool', 'char', '/')] = 'Error'

# Operaciones ==, <, > y mismo tipo
semantic_cube[('int', 'int', '==')] = 'bool'
semantic_cube[('int', 'int', '<')] = 'bool'
semantic_cube[('int', 'int', '>')] = 'bool'

semantic_cube[('float', 'float', '==')] = 'bool'
semantic_cube[('float', 'float', '<')] = 'bool'
semantic_cube[('float', 'float', '>')] = 'bool'

semantic_cube[('char', 'char', '==')] = 'bool'
semantic_cube[('char', 'char', '<')] = 'Error'
semantic_cube[('char', 'char', '>')] = 'Error'

semantic_cube[('bool', 'bool', '==')] = 'Error'
semantic_cube[('bool', 'bool', '<')] = 'Error'
semantic_cube[('bool', 'bool', '>')] = 'Error'

# Operaciones ==, <, >, int y diferente tipo
semantic_cube[('int', 'float', '==')] = 'bool'
semantic_cube[('int', 'char', '==')] = 'Error'
semantic_cube[('int', 'bool', '==')] = 'Error'

semantic_cube[('int', 'float', '<')] = 'bool'
semantic_cube[('int', 'char', '<')] = 'Error'
semantic_cube[('int', 'bool', '<')] = 'Error'

semantic_cube[('int', 'float', '>')] = 'bool'
semantic_cube[('int', 'char', '>')] = 'Error'
semantic_cube[('int', 'bool', '>')] = 'Error'

# Operaciones ==, <, >, float y diferente tipo
semantic_cube[('float', 'int', '==')] = 'bool'
semantic_cube[('float', 'char', '==')] = 'Error'
semantic_cube[('float', 'bool', '==')] = 'Error'

semantic_cube[('float', 'int', '<')] = 'bool'
semantic_cube[('float', 'char', '<')] = 'Error'
semantic_cube[('float', 'bool', '<')] = 'Error'

semantic_cube[('float', 'int', '>')] = 'bool'
semantic_cube[('float', 'char', '>')] = 'Error'
semantic_cube[('float', 'bool', '>')] = 'Error'

# Operaciones ==, <, >, char y diferente tipo
semantic_cube[('char', 'int', '==')] = 'Error'
semantic_cube[('char', 'float', '==')] = 'Error'
semantic_cube[('char', 'bool', '==')] = 'Error'

semantic_cube[('char', 'int', '<')] = 'Error'
semantic_cube[('char', 'float', '<')] = 'Error'
semantic_cube[('char', 'bool', '<')] = 'Error'

semantic_cube[('char', 'int', '>')] = 'Error'
semantic_cube[('char', 'float', '>')] = 'Error'
semantic_cube[('char', 'bool', '>')] = 'Error'

# Operaciones ==, <, >, bool y diferente tipo
semantic_cube[('bool', 'int', '==')] = 'Error'
semantic_cube[('bool', 'float', '==')] = 'Error'
semantic_cube[('bool', 'char', '==')] = 'Error'

semantic_cube[('bool', 'int', '<')] = 'Error'
semantic_cube[('bool', 'float', '<')] = 'Error'
semantic_cube[('bool', 'char', '<')] = 'Error'

semantic_cube[('bool', 'int', '>')] = 'Error'
semantic_cube[('bool', 'float', '>')] = 'Error'
semantic_cube[('bool', 'char', '>')] = 'Error'

# Operaciones &&, || y mismo tipo
semantic_cube[('int', 'int', '&&')] = 'Error'
semantic_cube[('int', 'int', '||')] = 'Error'

semantic_cube[('float', 'float', '&&')] = 'Error'
semantic_cube[('float', 'float', '||')] = 'Error'

semantic_cube[('char', 'char', '&&')] = 'Error'
semantic_cube[('char', 'char', '||')] = 'Error'

semantic_cube[('bool', 'bool', '&&')] = 'bool'
semantic_cube[('bool', 'bool', '||')] = 'bool'

# Operaciones &&, ||, int  y diferente tipo
semantic_cube[('int', 'float', '&&')] = 'Error'
semantic_cube[('int', 'char', '&&')] = 'Error'
semantic_cube[('int', 'bool', '&&')] = 'Error'

semantic_cube[('int', 'float', '||')] = 'Error'
semantic_cube[('int', 'char', '||')] = 'Error'
semantic_cube[('int', 'bool', '||')] = 'Error'

# Operaciones &&, ||, float  y diferente tipo
semantic_cube[('float', 'int', '&&')] = 'Error'
semantic_cube[('float', 'char', '&&')] = 'Error'
semantic_cube[('float', 'bool', '&&')] = 'Error'

semantic_cube[('float', 'int', '||')] = 'Error'
semantic_cube[('float', 'char', '||')] = 'Error'
semantic_cube[('float', 'bool', '||')] = 'Error'

# Operaciones &&, ||, char  y diferente tipo
semantic_cube[('char', 'int', '&&')] = 'Error'
semantic_cube[('char', 'float', '&&')] = 'Error'
semantic_cube[('char', 'bool', '&&')] = 'Error'

semantic_cube[('char', 'int', '||')] = 'Error'
semantic_cube[('char', 'float', '||')] = 'Error'
semantic_cube[('char', 'bool', '||')] = 'Error'

# Operaciones &&, ||, bool  y diferente tipo
semantic_cube[('bool', 'int', '&&')] = 'Error'
semantic_cube[('bool', 'float', '&&')] = 'Error'
semantic_cube[('bool', 'char', '&&')] = 'Error'

semantic_cube[('bool', 'int', '||')] = 'Error'
semantic_cube[('bool', 'float', '||')] = 'Error'
semantic_cube[('bool', 'char', '||')] = 'Error'


def get_result_type(operand1_type, operand2_type, operator):
    return semantic_cube.get((operand1_type, operand2_type, operator), 'Error')



precedence = (
    ('left', 'OR', 'AND'),             # Asociativo a la izquierda
    ('nonassoc', 'LESS_THAN', 'MORE_THAN', 'EQUAL_TO'),  # No asociativo
    ('left', 'PLUS', 'MINUS'),  # Asociativo a la izquierda
    ('left', 'MULT', 'DIV'),    # Asociativo a la izquierda
    ('right', 'UMINUS'),        # Asociativo a la derecha para el unario negativo, si existe
)

# Estructura del programa

def p_program(p):
    '''program : PROGRAM NAME PUNT_COMA vars multi_functions MAIN LEFTPAREN RIGHTPAREN block'''

def p_vars(p):
    '''vars : VARS var_list
            | empty'''

def p_var_list(p):
    '''var_list : var COMA var_list
                | var PUNT_COMA'''

def p_var(p):
    '''var : type NAME
           | type NAME LEFTSQUARE NUMBER RIGHTSQUARE'''
    if len(p) == 3:
        symbol_type = p[1]
        symbol_name = p[2]
        scope = 'global'
        symbol_table.add(symbol_name, symbol_type, scope)
    else:
        symbol_type = p[1]
        symbol_name = p[2]
        scope = 'global'
        symbol_table.add(symbol_name, symbol_type, scope)


def p_empty(p):
    'empty :'
    pass

def p_type(p):
    '''type : INT
            | FLOT
            | CHAR
            | VOID'''

def p_multi_functions(p):
    '''multi_functions : function multi_functions
                       | empty'''

def p_function(p):
    '''function : FUNCTION type NAME LEFTPAREN param_list RIGHTPAREN PUNT_COMA vars block '''
    function_type = p[2]
    function_name = p[3]
    ScopeManager.add_symbol(function_type, function_name, 'global')

def p_param_list(p):
    '''param_list : param COMA param_list
                  | param
                  | empty'''

def p_param(p):
    '''param : INT NAME
             | FLOT NAME
             | CHAR NAME'''

def p_block(p):
    '''block : LEFTCURLY statement_list RIGHTCURLY'''

def p_statement_list(p):
    '''statement_list : statement statement_list
                      | statement'''

def p_statement(p):
    '''statement : assignment
                 | function_call
                 | return_statement
                 | read_statement
                 | write_statement
                 | decision_statement
                 | repetition_statement'''

def p_assignment(p):
    '''assignment : NAME EQUALS expr PUNT_COMA
                  | NAME LEFTSQUARE expr RIGHTSQUARE EQUALS expr PUNT_COMA'''

def p_function_call(p):
    '''function_call : NAME LEFTPAREN var RIGHTPAREN PUNT_COMA
                     | NAME LEFTPAREN RIGHTPAREN PUNT_COMA'''

def p_return_statement(p):
    '''return_statement : RETURN LEFTPAREN expr RIGHTPAREN PUNT_COMA'''

def p_read_statement(p):
    '''read_statement : READ LEFTPAREN read_list RIGHTPAREN PUNT_COMA'''

def p_read_list(p):
    '''read_list : NAME COMA read_list
                 | NAME'''

def p_write_statement(p):
    '''write_statement : WRITE LEFTPAREN write_list RIGHTPAREN PUNT_COMA'''

def p_write_list(p):
    '''write_list : expr COMA write_list
                  | COMILLAS NAME COMILLAS COMA write_list
                  | expr
                  | COMILLAS NAME COMILLAS'''

def p_decision_statement(p):
    '''decision_statement : IF LEFTPAREN expr RIGHTPAREN THEN block
                          | IF LEFTPAREN expr RIGHTPAREN THEN block ELSE block'''

def p_repetition_statement(p):
    '''repetition_statement : FOR NAME EQUALS expr TO expr DO block
                            | WHILE LEFTPAREN expr RIGHTPAREN DO block'''

def p_expr(p):
    '''expr : expr PLUS expr
            | expr MINUS expr
            | expr MULT expr
            | expr DIV expr
            | expr AND expr
            | expr OR expr
            | expr LESS_THAN expr
            | expr MORE_THAN expr
            | expr EQUAL_TO expr
            | LEFTPAREN expr RIGHTPAREN
            | MINUS expr %prec UMINUS
            | NUMBER
            | NAME
            | CONST_FLOAT'''

def p_error(p):
    if p:
        print(f"Syntax error at token {p.type} - Line: {p.lineno}, Position: {p.lexpos}")
    else:
        print("Syntax error at EOF")

parser = yacc.yacc()

# Tokenize
##while True:
  #  tok = lexer.token()
   # if not tok:
    #    break      # No more input
    #print(tok.type, tok.value, tok.lineno, tok.lexpos)

# Programa_Asignación
# Vars
# int i;
# int j;
# char Emilio;
# main() {
# i = 5 ;
# j = 6 ;
# Emilio = “Emilio”
# }
