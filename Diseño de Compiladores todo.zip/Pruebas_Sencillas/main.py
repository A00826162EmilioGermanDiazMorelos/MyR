import ply.lex as lex
import ply.yacc as yacc

reserved = {
    'Program': 'PROGRAM',
    'main': 'MAIN',
    'int': 'INT',
    'flot': 'FLOT',
    'char': 'CHAR',
    'void': 'VOID',
    'vars': 'VARS',
    'function': 'FUNCTION',
    'return': 'RETURN',
    'read': 'READ',
    'write': 'WRITE',
    'If': 'IF',
    'then': 'THEN',
    'else': 'ELSE',
    'while': 'WHILE',
    'for': 'FOR',
    'to': 'TO',
    'do': 'DO'
}

tokens = ['PLUS', 'MINUS', 'MULT', 'DIV', 'EQUALS', 'AND', 'OR', 'LESS_THAN', 'MORE_THAN',
          'EQUAL_TO', 'NUMBER', 'CONST_FLOAT', 'NAME', 'LEFTPAREN', 'RIGHTPAREN', 'LEFTCURLY', 'RIGHTCURLY',
          'LEFTSQUARE', 'RIGHTSQUARE', 'PUNT_COMA', 'COMA', 'COMILLAS'] + list(reserved.values())

# Ignorar espacios en blanco y saltos de línea
t_ignore = ' \t'

# Expresiones regulares para operaciones aritméticas
t_PLUS = r'\+'
t_MINUS = r'-'
t_MULT = r'\*'
t_DIV = r'/'
t_EQUALS = r'='

# Expresiones regulares para operaciones lógicas
t_AND = r'&'
t_OR = r'\|'
t_LESS_THAN = r'<'
t_MORE_THAN = r'>'
t_EQUAL_TO = r'=='

# Expresiones regulares para abrir y cerrar paréntesis, corchetes y llaves, y signos de puntuación
t_LEFTPAREN = r'\('
t_RIGHTPAREN = r'\)'
t_LEFTCURLY = r'\{'
t_RIGHTCURLY = r'\}'
t_LEFTSQUARE = r'\['
t_RIGHTSQUARE = r'\]'
t_PUNT_COMA = r';'
t_COMA = r','
t_COMILLAS = r'"'

# Expresión regular para reconocer números enteros
def t_NUMBER(t):
    r'\d+'
    t.value = int(t.value)
    return t

def t_CONST_FLOAT(t):
    r'\d\.\d+'
    t.value = float(t.value)
    return t

def t_NAME(t):
    r'[a-zA-Z_][a-zA-Z_0-9]*'
    t.type = reserved.get(t.value, 'NAME')  # Checa palabras reservadas
    return t

# Manejo de errores
def t_error(t):
    print(f"Caracter ilegal: {t.value[0]}")
    t.lexer.skip(1)

# Construir el lexer
lexer = lex.lex()

# PARSER
class ProcedureEntry:
    def __init__(self, name, return_type, parameters, start_address):
        self.name = name
        self.return_type = return_type
        self.parameters = parameters  # Esto podría ser una lista de (tipo, nombre)
        self.start_address = start_address
        self.local_variables = {}  # Esto es un diccionario para las variables locales

    def add_variable(self, var_name, var_type):
        self.local_variables[var_name] = var_type

    def __repr__(self):
        return (f"Procedure {self.name}: Return Type: {self.return_type}, "
                f"Parameters: {self.parameters}, Start Address: {self.start_address}, "
                f"Local Variables: {self.local_variables}")


class ProcedureDirectory:
    def __init__(self):
        self.procedures = {}

    def add_procedure(self, name, return_type, parameters, start_address):
        if name in self.procedures:
            raise ValueError(f"Procedure '{name}' already defined")
        self.procedures[name] = ProcedureEntry(name, return_type, parameters, start_address)

    def get_procedure(self, name):
        return self.procedures.get(name)

    def __repr__(self):
        return "\n".join(str(proc) for proc in self.procedures.values())

procedure_directory = ProcedureDirectory()

#Tabla de simbolos

class SymbolTableEntry:
    def __init__(self, name, symbol_type, scope, address=None, value=None):
        self.name = name
        self.symbol_type = symbol_type
        self.scope = scope
        self.address = address
        self.value = value  # Valor de la variable

    def __repr__(self):
        return f"Symbol(name={self.name}, type={self.symbol_type}, scope={self.scope}, address={self.address}, value={self.value})"

class SymbolTable:
    def __init__(self):
        self.table = {}

    def add(self, name, symbol_type, scope, address=None, value=None):
        if name in self.table:
            raise ValueError(f"Symbol {name} already defined in current scope")
        entry = SymbolTableEntry(name, symbol_type, scope, address, value)
        self.table[name] = entry

    def update_value(self, name, value):
        if name in self.table:
            self.table[name].value = value
        else:
            raise ValueError(f"Symbol {name} not found in current scope")

    def lookup(self, name):
        return self.table.get(name)

    def __repr__(self):
        return str(self.table)


class ScopeManager:
    def __init__(self):
        self.global_scope = SymbolTable()
        self.scopes = [self.global_scope]

    def enter_scope(self):
        self.scopes.append(SymbolTable())

    def exit_scope(self):
        self.scopes.pop()

    def current_scope(self):
        return self.scopes[-1]

    def add_symbol(self, name, symbol_type, scope, address=None, value=None):
        self.current_scope().add(name, symbol_type, scope, address, value)

    def update_symbol_value(self, name, value):
        for scope in reversed(self.scopes):
            try:
                scope.update_value(name, value)
                return
            except ValueError:
                continue
        raise ValueError(f"Symbol {name} not found in any scope")

    def lookup(self, name):
        for scope in reversed(self.scopes):
            symbol = scope.lookup(name)
            if symbol:
                return symbol
        return None

#Cuádruplos

class Quadruple:
    def __init__(self, operator, operand1, operand2, result):
        self.operator = operator
        self.operand1 = operand1
        self.operand2 = operand2
        self.result = result

    def __repr__(self):
        return f"({self.operator}, {self.operand1}, {self.operand2}, {self.result})"

quadruples = []

def add_quadruple(operator, operand1, operand2, result):
    quadruple = Quadruple(operator, operand1, operand2, result)
    quadruples.append(quadruple)
    return quadruple

def get_quadruple(index):
    return quadruples[index]


# Funciones para manejar cuádruplos

def print_quadruples():
    for i, quad in enumerate(quadruples):
        print(f"{i}: {quad}")

# Generación de Variables Temporales

temp_counter = 0

def generate_temporary():
    global temp_counter
    temp_name = f"temp{temp_counter}"
    temp_counter += 1
    return temp_name

# Generación de direcciones de memoria
memory_address_counter = 0

def generate_memory_address():
    global memory_address_counter
    address = memory_address_counter
    memory_address_counter += 1
    return address

# Pilas de Operadores, Operandos y Saltos

def evaluate_expression(expr):
    if isinstance(expr, SymbolTableEntry):
        # Si expr es una variable, devuelve su dirección
        return expr.address
    elif isinstance(expr, (int, float)):
        # Si expr es un valor constante, asignarlo a una dirección temporal
        temp_address = generate_temporary()
        add_quadruple('=', expr, None, temp_address)
        return temp_address
    elif isinstance(expr, tuple):
        operator, operand1, operand2 = expr
        # Evaluar los operandos, que pueden ser constantes, variables o expresiones
        address1 = evaluate_expression(operand1)
        address2 = evaluate_expression(operand2)
        # Generar cuádruplo para la operación y devolver la dirección temporal del resultado
        result_address = generate_temporary()
        add_quadruple(operator, address1, address2, result_address)
        return result_address

operators_stack = []
operands_stack = []
jumps_stack = []
symbol_table = []
global_scope_manager = ScopeManager()


#Cubo Semántico
#posibles tipos de datos
types = ['int', 'float', 'char', 'bool']
#operadores binarios
operators = ['+', '-', '*', '/', '==', '<', '>', '&', '|']

semantic_cube = {}

#Operaciones +, -, /, *, mismo tipo
semantic_cube[('int', 'int', '+')] = 'int'
semantic_cube[('int', 'int', '-')] = 'int'
semantic_cube[('int', 'int', '*')] = 'int'
semantic_cube[('int', 'int', '/')] = 'int'

semantic_cube[('float', 'float', '+')] = 'float'
semantic_cube[('float', 'float', '-')] = 'float'
semantic_cube[('float', 'float', '*')] = 'float'
semantic_cube[('float', 'float', '/')] = 'float'

semantic_cube[('char', 'char', '+')] = 'Error'
semantic_cube[('char', 'char', '-')] = 'Error'
semantic_cube[('char', 'char', '*')] = 'Error'
semantic_cube[('char', 'char', '/')] = 'Error'

semantic_cube[('bool', 'bool', '+')] = 'Error'
semantic_cube[('bool', 'bool', '-')] = 'Error'
semantic_cube[('bool', 'bool', '*')] = 'Error'
semantic_cube[('bool', 'bool', '/')] = 'Error'

#Operaciones +, -, /, *, int y diferente tipo
semantic_cube[('int', 'float', '+')] = 'float'
semantic_cube[('int', 'char', '+')] = 'Error'
semantic_cube[('int', 'bool', '+')] = 'Error'

semantic_cube[('int', 'float', '-')] = 'float'
semantic_cube[('int', 'char', '-')] = 'Error'
semantic_cube[('int', 'bool', '-')] = 'Error'

semantic_cube[('int', 'float', '*')] = 'float'
semantic_cube[('int', 'char', '*')] = 'Error'
semantic_cube[('int', 'bool', '*')] = 'Error'

semantic_cube[('int', 'float', '/')] = 'float'
semantic_cube[('int', 'char', '/')] = 'Error'
semantic_cube[('int', 'bool', '/')] = 'Error'

#Operaciones +, -, /, *, float y diferente tipo
semantic_cube[('float', 'int', '+')] = 'float'
semantic_cube[('float', 'char', '+')] = 'Error'
semantic_cube[('float', 'bool', '+')] = 'Error'

semantic_cube[('float', 'int', '-')] = 'float'
semantic_cube[('float', 'char', '-')] = 'Error'
semantic_cube[('float', 'bool', '-')] = 'Error'

semantic_cube[('float', 'int', '*')] = 'float'
semantic_cube[('float', 'char', '*')] = 'Error'
semantic_cube[('float', 'bool', '*')] = 'Error'

semantic_cube[('float', 'int', '/')] = 'float'
semantic_cube[('float', 'char', '/')] = 'Error'
semantic_cube[('float', 'bool', '/')] = 'Error'

#Operaciones +, -, /, *, char y diferente tipo
semantic_cube[('char', 'int', '+')] = 'Error'
semantic_cube[('char', 'float', '+')] = 'Error'
semantic_cube[('char', 'bool', '+')] = 'Error'

semantic_cube[('char', 'int', '-')] = 'Error'
semantic_cube[('char', 'float', '-')] = 'Error'
semantic_cube[('char', 'bool', '-')] = 'Error'

semantic_cube[('char', 'int', '*')] = 'Error'
semantic_cube[('char', 'float', '*')] = 'Error'
semantic_cube[('char', 'bool', '*')] = 'Error'

semantic_cube[('char', 'int', '/')] = 'Error'
semantic_cube[('char', 'float', '/')] = 'Error'
semantic_cube[('char', 'bool', '/')] = 'Error'

#Operaciones +, -, /, *, bool y diferente tipo
semantic_cube[('bool', 'int', '+')] = 'Error'
semantic_cube[('bool', 'float', '+')] = 'Error'
semantic_cube[('bool', 'char', '+')] = 'Error'

semantic_cube[('bool', 'int', '-')] = 'Error'
semantic_cube[('bool', 'float', '-')] = 'Error'
semantic_cube[('bool', 'char', '-')] = 'Error'

semantic_cube[('bool', 'int', '*')] = 'Error'
semantic_cube[('bool', 'float', '*')] = 'Error'
semantic_cube[('bool', 'char', '*')] = 'Error'

semantic_cube[('bool', 'int', '/')] = 'Error'
semantic_cube[('bool', 'float', '/')] = 'Error'
semantic_cube[('bool', 'char', '/')] = 'Error'

# Operaciones ==, <, > y mismo tipo
semantic_cube[('int', 'int', '==')] = 'bool'
semantic_cube[('int', 'int', '<')] = 'bool'
semantic_cube[('int', 'int', '>')] = 'bool'

semantic_cube[('float', 'float', '==')] = 'bool'
semantic_cube[('float', 'float', '<')] = 'bool'
semantic_cube[('float', 'float', '>')] = 'bool'

semantic_cube[('char', 'char', '==')] = 'bool'
semantic_cube[('char', 'char', '<')] = 'Error'
semantic_cube[('char', 'char', '>')] = 'Error'

semantic_cube[('bool', 'bool', '==')] = 'Error'
semantic_cube[('bool', 'bool', '<')] = 'Error'
semantic_cube[('bool', 'bool', '>')] = 'Error'

# Operaciones ==, <, >, int y diferente tipo
semantic_cube[('int', 'float', '==')] = 'bool'
semantic_cube[('int', 'char', '==')] = 'Error'
semantic_cube[('int', 'bool', '==')] = 'Error'

semantic_cube[('int', 'float', '<')] = 'bool'
semantic_cube[('int', 'char', '<')] = 'Error'
semantic_cube[('int', 'bool', '<')] = 'Error'

semantic_cube[('int', 'float', '>')] = 'bool'
semantic_cube[('int', 'char', '>')] = 'Error'
semantic_cube[('int', 'bool', '>')] = 'Error'

# Operaciones ==, <, >, float y diferente tipo
semantic_cube[('float', 'int', '==')] = 'bool'
semantic_cube[('float', 'char', '==')] = 'Error'
semantic_cube[('float', 'bool', '==')] = 'Error'

semantic_cube[('float', 'int', '<')] = 'bool'
semantic_cube[('float', 'char', '<')] = 'Error'
semantic_cube[('float', 'bool', '<')] = 'Error'

semantic_cube[('float', 'int', '>')] = 'bool'
semantic_cube[('float', 'char', '>')] = 'Error'
semantic_cube[('float', 'bool', '>')] = 'Error'

# Operaciones ==, <, >, char y diferente tipo
semantic_cube[('char', 'int', '==')] = 'Error'
semantic_cube[('char', 'float', '==')] = 'Error'
semantic_cube[('char', 'bool', '==')] = 'Error'

semantic_cube[('char', 'int', '<')] = 'Error'
semantic_cube[('char', 'float', '<')] = 'Error'
semantic_cube[('char', 'bool', '<')] = 'Error'

semantic_cube[('char', 'int', '>')] = 'Error'
semantic_cube[('char', 'float', '>')] = 'Error'
semantic_cube[('char', 'bool', '>')] = 'Error'

# Operaciones ==, <, >, bool y diferente tipo
semantic_cube[('bool', 'int', '==')] = 'Error'
semantic_cube[('bool', 'float', '==')] = 'Error'
semantic_cube[('bool', 'char', '==')] = 'Error'

semantic_cube[('bool', 'int', '<')] = 'Error'
semantic_cube[('bool', 'float', '<')] = 'Error'
semantic_cube[('bool', 'char', '<')] = 'Error'

semantic_cube[('bool', 'int', '>')] = 'Error'
semantic_cube[('bool', 'float', '>')] = 'Error'
semantic_cube[('bool', 'char', '>')] = 'Error'

# Operaciones &&, || y mismo tipo
semantic_cube[('int', 'int', '&&')] = 'Error'
semantic_cube[('int', 'int', '||')] = 'Error'

semantic_cube[('float', 'float', '&&')] = 'Error'
semantic_cube[('float', 'float', '||')] = 'Error'

semantic_cube[('char', 'char', '&&')] = 'Error'
semantic_cube[('char', 'char', '||')] = 'Error'

semantic_cube[('bool', 'bool', '&&')] = 'bool'
semantic_cube[('bool', 'bool', '||')] = 'bool'

# Operaciones &&, ||, int  y diferente tipo
semantic_cube[('int', 'float', '&&')] = 'Error'
semantic_cube[('int', 'char', '&&')] = 'Error'
semantic_cube[('int', 'bool', '&&')] = 'Error'

semantic_cube[('int', 'float', '||')] = 'Error'
semantic_cube[('int', 'char', '||')] = 'Error'
semantic_cube[('int', 'bool', '||')] = 'Error'

# Operaciones &&, ||, float  y diferente tipo
semantic_cube[('float', 'int', '&&')] = 'Error'
semantic_cube[('float', 'char', '&&')] = 'Error'
semantic_cube[('float', 'bool', '&&')] = 'Error'

semantic_cube[('float', 'int', '||')] = 'Error'
semantic_cube[('float', 'char', '||')] = 'Error'
semantic_cube[('float', 'bool', '||')] = 'Error'

# Operaciones &&, ||, char  y diferente tipo
semantic_cube[('char', 'int', '&&')] = 'Error'
semantic_cube[('char', 'float', '&&')] = 'Error'
semantic_cube[('char', 'bool', '&&')] = 'Error'

semantic_cube[('char', 'int', '||')] = 'Error'
semantic_cube[('char', 'float', '||')] = 'Error'
semantic_cube[('char', 'bool', '||')] = 'Error'

# Operaciones &&, ||, bool  y diferente tipo
semantic_cube[('bool', 'int', '&&')] = 'Error'
semantic_cube[('bool', 'float', '&&')] = 'Error'
semantic_cube[('bool', 'char', '&&')] = 'Error'

semantic_cube[('bool', 'int', '||')] = 'Error'
semantic_cube[('bool', 'float', '||')] = 'Error'
semantic_cube[('bool', 'char', '||')] = 'Error'

def get_result_type(operand1_type, operand2_type, operator):
    return semantic_cube.get((operand1_type, operand2_type, operator), 'Error')


precedence = (
    ('left', 'OR', 'AND'),             # Asociativo a la izquierda
    ('nonassoc', 'LESS_THAN', 'MORE_THAN', 'EQUAL_TO'),  # No asociativo
    ('left', 'PLUS', 'MINUS'),  # Asociativo a la izquierda
    ('left', 'MULT', 'DIV'),    # Asociativo a la izquierda
    ('right', 'UMINUS'),        # Asociativo a la derecha para el unario negativo, si existe
)

# Estructura del programa

def p_program(p):
    '''program : PROGRAM NAME PUNT_COMA vars multi_functions MAIN LEFTPAREN RIGHTPAREN block'''

def p_vars(p):
    '''vars : VARS var_list
            | empty'''

def p_var_list(p):
    '''var_list : var COMA var_list
                | var PUNT_COMA'''

def p_var(p):
    '''var : type NAME
           | type NAME LEFTSQUARE NUMBER RIGHTSQUARE'''
    symbol_type = p[1]
    symbol_name = p[2]
    scope = 'global'
    address = generate_memory_address()

    # Referenciar la instancia global de ScopeManager
    if len(p) == 3:
        global_scope_manager.add_symbol(symbol_name, symbol_type, scope, address=address, value=0)
    else:
        symbol_size = p[4]
        global_scope_manager.add_symbol(symbol_name, symbol_type, scope, address=address, value=[0]*symbol_size)

    print(global_scope_manager.lookup(symbol_name))



def p_empty(p):
    'empty :'
    pass

def p_type(p):
    '''type : INT
            | FLOT
            | CHAR
            | VOID'''

def p_multi_functions(p):
    '''multi_functions : function multi_functions
                       | empty'''

def p_function(p):
    '''function : FUNCTION type NAME LEFTPAREN param_list RIGHTPAREN PUNT_COMA vars block '''
   # function_type = p[2]
   # function_name = p[3]
   # ScopeManager.add_symbol(function_type, function_name, 'global')

def p_param_list(p):
    '''param_list : param COMA param_list
                  | param
                  | empty'''

def p_param(p):
    '''param : INT NAME
             | FLOT NAME
             | CHAR NAME'''

def p_block(p):
    '''block : LEFTCURLY statement_list RIGHTCURLY'''

def p_statement_list(p):
    '''statement_list : statement statement_list
                      | statement'''

def p_statement(p):
    '''statement : assignment
                 | function_call
                 | return_statement
                 | read_statement
                 | write_statement
                 | decision_statement
                 | repetition_statement'''


def p_assignment(p):
    '''assignment : NAME EQUALS expr PUNT_COMA
                  | NAME LEFTSQUARE expr RIGHTSQUARE EQUALS expr PUNT_COMA'''
    variable_name = p[1]

    if len(p) == 5:
        # Asignación simple
        expression_result = evaluate_expression(p[3])
        variable_entry = global_scope_manager.lookup(variable_name)

        if variable_entry is None:
            raise ValueError(f"Variable {variable_name} not declared")

        # Generar cuádruplo para la asignación
        add_quadruple('=', expression_result, None, variable_entry.address)
        # Actualizar el valor en la tabla de símbolos
        global_scope_manager.update_symbol_value(variable_name, expression_result)


def p_function_call(p):
    '''function_call : NAME LEFTPAREN var RIGHTPAREN PUNT_COMA
                     | NAME LEFTPAREN RIGHTPAREN PUNT_COMA'''

def p_return_statement(p):
    '''return_statement : RETURN LEFTPAREN expr RIGHTPAREN PUNT_COMA'''

def p_read_statement(p):
    '''read_statement : READ LEFTPAREN read_list RIGHTPAREN PUNT_COMA'''
    # p[3] es la lista de variables a leer
    read_variables = p[3]
    for var in read_variables:
        add_quadruple('READ', None, None, var)

def p_read_list(p):
    '''read_list : NAME COMA read_list
                 | NAME'''
    if len(p) == 4:
        # Agregar la variable actual a la lista y combinar con las siguientes
        p[0] = [p[1]] + p[3]
    else:
        # Solo una variable
        p[0] = [p[1]]

def p_write_statement(p):
    '''write_statement : WRITE LEFTPAREN write_list RIGHTPAREN PUNT_COMA'''
    # p[3] es la lista de expresiones o cadenas a escribir
    write_elements = p[3]
    for elem in write_elements:
        if isinstance(elem, str):  # Verificar si es una cadena
            add_quadruple('WRITE', None, None, elem)
        else:
            # Para expresiones, asumimos que elem es una dirección o valor
            add_quadruple('WRITE', None, None, elem)

def p_write_list(p):
    '''write_list : expr COMA write_list
                  | COMILLAS NAME COMILLAS COMA write_list
                  | expr
                  | COMILLAS NAME COMILLAS'''
    if len(p) == 4 or len(p) == 6:
        # Lista con más de un elemento (expr o cadena)
        p[0] = [evaluate_expression(p[1])] + p[3]
    else:
        # Solo un elemento (expr o cadena)
        if p[1].startswith('"') and p[1].endswith('"'):
            p[0] = [p[1][1:-1]]  # Eliminar las comillas y agregar la cadena
        else:
            p[0] = [evaluate_expression(p[1])]


def p_decision_statement(p):
    '''decision_statement : IF LEFTPAREN expr RIGHTPAREN THEN block
                          | IF LEFTPAREN expr RIGHTPAREN THEN block ELSE block'''

def p_repetition_statement(p):
    '''repetition_statement : FOR NAME EQUALS expr TO expr DO block
                            | WHILE LEFTPAREN expr RIGHTPAREN DO block'''

def p_expr(p):
    '''expr : expr PLUS expr
            | expr MINUS expr
            | expr MULT expr
            | expr DIV expr
            | expr AND expr
            | expr OR expr
            | expr LESS_THAN expr
            | expr MORE_THAN expr
            | expr EQUAL_TO expr
            | LEFTPAREN expr RIGHTPAREN
            | MINUS expr %prec UMINUS
            | NUMBER
            | NAME
            | CONST_FLOAT'''

    if len(p) == 4:
        # Operaciones binarias
        operand1 = evaluate_expression(p[1])
        operand2 = evaluate_expression(p[3])
        operator = p[2]
        # Generar una dirección temporal para el resultado
        result_address = generate_temporary()
        # Agregar el cuádruplo correspondiente a la operación
        add_quadruple(operator, operand1, operand2, result_address)
        # El resultado será la dirección temporal donde se almacena el resultado
        p[0] = result_address

    elif len(p) == 3:
        # Operaciones con numero negativo
        operand = evaluate_expression(p[2])
        result_address = generate_temporary()
        add_quadruple(p[1], operand, None, result_address)
        p[0] = result_address

    else:
        # Números, nombres de variables o constantes flotantes
        # Aquí, evaluamos directamente la expresión y devolvemos su valor o dirección
        p[0] = evaluate_expression(p[1])

def p_error(p):
    if p:
        print(f"Syntax error at token {p.type} - Line: {p.lineno}, Position: {p.lexpos}")
    else:
        print("Syntax error at EOF")

parser = yacc.yacc()

# Prueba de Parser

#test_program = """ Program Assign ; Vars int uno; int dos[3]; main() { uno = 5 ; dos = 6 ; } """
#result = parser.parse(test_program)

#########################################################################################
# Pruebas

scope_manager = ScopeManager()
scope_manager.add_symbol("x", "int", "global", value=5)
print(scope_manager.lookup("x"))
scope_manager.update_symbol_value("x", 10)
print(scope_manager.lookup("x"))

test_program2 = '''
Program Expresiones ;
vars int a;
main ( ) {
    a = 5;
}
'''
parser.parse(test_program2, lexer=lexer)

print_quadruples()

lexer.input(test_program2)
while True:
    tok = lexer.token()
    if not tok:
        break
    print(tok)

####################################################################################

scope_manager = ScopeManager()
scope_manager.add_symbol("Emilio", "char", "global", value="Emilio")
print(scope_manager.lookup("Emilio"))
scope_manager.update_symbol_value("Emilio", "Diaz")
print(scope_manager.lookup("Emilio"))

test_program3 = '''
Program Expresiones ;
vars char Emilio;
main ( ) {
    Emilio = "Emilio" ;
    write ( Emilio ) ;
    read ( Emilio ) ;
}
'''
parser.parse(test_program3, lexer=lexer)

print_quadruples()

lexer.input(test_program3)
while True:
    tok = lexer.token()
    if not tok:
        break
    print(tok)